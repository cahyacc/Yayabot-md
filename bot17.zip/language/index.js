exports.indonesia = require('./indonesia')
exports.english = require('./english')
exports.spanyol = require('./spanyol')
